#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

char *greet(const char *name);

char *transfer_spl_token(const char *relay_program_id,
                         const char *sender_token_account_address,
                         const char *recipient_address,
                         const char *token_mint_address,
                         const char *authority_address,
                         uint64_t amount,
                         uint8_t decimals,
                         uint64_t fee_amount,
                         const char *blockhash,
                         uint64_t minimum_token_account_balance,
                         bool needs_create_recipient_token_account,
                         const char *fee_payer_address);

char *top_up(const char *relay_program_id,
             const char *user_source_token_account_address,
             const char *source_token_mint_address,
             const char *authority_address,
             const char *swap_data,
             uint64_t fee_amount,
             const char *blockhash,
             uint64_t minimum_relay_account_balance,
             uint64_t minimum_token_account_balance,
             bool needs_create_user_relay_account,
             const char *fee_payer_address);

char *sign_transaction(const char *transaction, const char *keypair, const char *blockhash);

char *get_solend_collateral_accounts(const char *rpc_url, const char *owner);
